'use strict';
window.mocks = window.mocks || {};
window.mocks.vpnprelogin = window.mocks.vpnprelogin || {};
