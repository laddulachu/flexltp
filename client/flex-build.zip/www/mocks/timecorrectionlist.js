'use strict';
window.mocks = window.mocks || {};
window.mocks.timecorrectionlist = window.mocks.timecorrectionlist || {};
