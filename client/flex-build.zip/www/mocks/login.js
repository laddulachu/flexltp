'use strict';
window.mocks = window.mocks || {};
window.mocks.login = window.mocks.login || {};
