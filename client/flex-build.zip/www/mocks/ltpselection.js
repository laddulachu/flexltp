'use strict';
window.mocks = window.mocks || {};
window.mocks.ltpselection = window.mocks.ltpselection || {};
