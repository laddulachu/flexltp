'use strict';
window.mocks = window.mocks || {};
window.mocks.home = window.mocks.home || {};
