'use strict';
window.mocks = window.mocks || {};
window.mocks.postlogin = window.mocks.postlogin || {};
