'use strict';
window.mocks = window.mocks || {};
window.mocks.leaveapproval = window.mocks.leaveapproval || {};
