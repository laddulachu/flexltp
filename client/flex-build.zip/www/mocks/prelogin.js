'use strict';
window.mocks = window.mocks || {};
window.mocks.prelogin = window.mocks.prelogin || {};
