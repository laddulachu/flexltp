'use strict';
window.mocks = window.mocks || {};
window.mocks.rejectcomment = window.mocks.rejectcomment || {};
