'use strict';
window.mocks = window.mocks || {};
window.mocks.approvecomment = window.mocks.approvecomment || {};
