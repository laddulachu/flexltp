'use strict';
window.mocks = window.mocks || {};
window.mocks.vpnlogin = window.mocks.vpnlogin || {};
