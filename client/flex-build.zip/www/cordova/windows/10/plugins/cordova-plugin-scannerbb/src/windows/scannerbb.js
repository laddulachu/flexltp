cordova.define("cordova-plugin-scannerbb.ScannerProxy", function (require, exports, module) {

    var _claimedScanner = null;

    function setBBProfile(profile) {
        // Valid profiles are: " ", "IDCard", "Passport", "VisaA2", "VisaB2", "VisaBCC", "USAPRC"
        return new Promise(function (resolve, reject) {
            if(window.Powwow && window.Powwow.ScannerAPI) {
                var scannerAPI = new Powwow.ScannerAPI();
                var bbScannerAPI = scannerAPI.getBBScannerAPI();
                bbScannerAPI.initialize().then(function (success) {
                    if (success) {
                        bbScannerAPI.barcodeOEMProfileSet(profile).then(function (success) {
                            if (success) {
                                bbScannerAPI.cleanup().then(function (success) {
                                    if (success) {
                                        resolve();
                                    } else {
                                        reject("Failed to cleanup while setting BB profile: '" + profile + "'");
                                    }
                                });
                            } else {
                                reject("Failed call barcodeOEMProfileSet while setting BB profile: '" + profile + "'");
                            }
                        });
                    } else {
                        reject("Failed call initialize while setting BB profile: '" + profile + "'");
                    }
                });
            } else {
                reject("Failed to locate Scanner Profile setter API.");
            }
        });
    }

    function releaseScanner() {
        if (_claimedScanner != null) {
            try {
                _claimedScanner.close();
            } catch (e) {
                // May already be closed.
            }
            _claimedScanner = null;
        }
    }

    function resetScanner() {
        return new Promise(function (resolve) {
            if (_claimedScanner) {
                _claimedScanner.removeEventListener("datareceived", onDataReceived);
                _claimedScanner.removeEventListener("releasedevicerequested", onReleasedeviceRequested);
                _claimedScanner.removeEventListener("triggerpressed", onTriggerPressed);
                _claimedScanner.removeEventListener("triggerreleased", onTriggerReleased);
            }
            releaseScanner();
            resolve();
        });
    }

    function startScanner(successCallback, errorCallback) {

        Windows.Devices.PointOfService.BarcodeScanner.getDefaultAsync().then(function (scanner) {
            console.log("Windows.Devices.PointOfService.BarcodeScanner.getDefaultAsync() succesfull");
            if (scanner !== null) {
                console.log("scanner is not null");

                // After successful creation, claim the scanner for exclusive use and enable it so that data reveived events are received.
                scanner.claimScannerAsync().then(function (claimedScanner) {
                    console.log("scanner.claimScannerAsync()");
                    if (claimedScanner !== null) {
                        console.log("claimedScanner is not null");
                        _claimedScanner = claimedScanner;

                        // Ask the API to decode the data by default. By setting this, API will decode the raw data from the barcode scanner and 
                        // send the ScanDataLabel and ScanDataType in the DataReceived event
                        _claimedScanner.isDecodeDataEnabled = true;


                        // Enable the scanner.
                        // Note: If the scanner is not enabled (i.e. EnableAsync not called), attaching the event handler will not be any useful because the API will not fire the event 
                        // if the claimedScanner has not beed Enabled
                        _claimedScanner.enableAsync().then(function (response) {
                            console.log("_claimedScanner.enableAsync(), device id=", _claimedScanner.deviceId);
                            // After successfully claiming, attach the datareceived event handler.
                            _claimedScanner.addEventListener("datareceived", onDataReceived);
                            _claimedScanner.addEventListener("triggerpressed", onTriggerPressed);
                            _claimedScanner.addEventListener("triggerreleased", onTriggerReleased);
                            _claimedScanner.addEventListener("releasedevicerequested", onReleasedeviceRequested);
                            //WinJS.log("Ready to scan. Device ID: " + _claimedScanner.deviceId, "sample", "status");
                            successCallback({ 'output': "Ready to scan. Device ID: " + _claimedScanner.deviceId });
                        }, function error(e) {
                            //WinJS.log("Enable barcode scanner failed: " + e.message, "sample", "error")
                            errorCallback({ error: "initialize", message: "Enable barcode scanner failed: " + e.message });
                        });

                    } else {
                        //WinJS.log("Claim barcode scanner failed.", "sample", "error");
                        errorCallback({ error: "initialize", message: "Claim barcode scanner failed." });
                    }
                }, function (e) {
                    // WinJS.log("Claim barcode scanner failed: " + e.message, "sample", "error");
                    errorCallback({ error: "initialize", message: "Claim barcode scanner failed: " + e.message });
                });

            } else {
                //WinJS.log("Barcode scanner not found. Please connect a barcode scanner.", "sample", "error");
                errorCallback({ error: "initialize", message: "Barcode scanner not found 2. Please connect a barcode scanner." + deviceSelector });
            }

        }, function (e) {
            //WinJS.log("Barcode scanner FromIdAsync unsuccessful: " + e.message, "sample", "error");
            errorCallback({ error: "initialize", message: "Barcode scanner FromIdAsync unsuccessful: " + e.message });
        });
        //     }
        // });

    }

    module.exports = {

        enable: function (successCallback, errorCallback, args) {
            var profile = args[0];
            if (!profile) {
                profile = " ";
            }

            resetScanner().then(function () {
                setTimeout(function () {
                    setBBProfile(profile).then(function () {
                        console.log("Set Scanner profile to " + profile);
                        startScanner(successCallback, errorCallback);
                    }, function (message) {
                        console.log("Set Scanner profile failed to " + profile);
                        errorCallback({ error: "initialize", message: message });
                    })
                }, 100);
            })

        },
        disable: function (successCallback, errorCallback) {
            resetScanner().then(function () {
                successCallback({ 'output': "scanner stopped with eventListener cleared" });
            });
        }
    };
    // Event handler for the Release Device Requested event fired when barcode scanner receives Claim request from another application
    function onReleasedeviceRequested(args) {
        console.log("onReleasedeviceRequested");
        _claimedScanner.retainDevice();
        //WinJS.log("Event ReleaseDeviceRequested received. Retaining the barcode scanner.", "sample", "status");
    }

    // Event handler for the DataReceived event fired when a barcode is scanned by the barcode scanner 
    function onDataReceived(args) {
        var scanType = Windows.Devices.PointOfService.BarcodeSymbologies.getName(args.report.scanDataType);
        cordova.fireWindowEvent('barcodeRead', { codeType: scanType, data: getDataLabelString(args.report.scanDataLabel, scanType) });
    }

    function onTriggerPressed() {
        cordova.fireWindowEvent('barcodeTriggerPressed', {});
    }

    function onTriggerReleased() {
        cordova.fireWindowEvent('barcodeTriggerReleased', {});
    }

    function getDataString(data) {
        var result = "";

        if (data === null) {
            result = "No data";
        }
        else {
            // Just to show that we have the raw data, we'll print the value of the bytes.
            // Arbitrarily limit the number of bytes printed to 20 so the UI isn't overloaded.
            var MAX_BYTES_TO_PRINT = 600;
            var bytesToPrint = (data.length < MAX_BYTES_TO_PRINT) ? data.length : MAX_BYTES_TO_PRINT;

            var reader = Windows.Storage.Streams.DataReader.fromBuffer(data);

            for (var byteIndex = 0; byteIndex < bytesToPrint; ++byteIndex) {
                result += reader.readByte().toString(16) + " ";
            }

            if (bytesToPrint < data.length) {
                result += "...";
            }
        }

        return result;
    }

    function isPrintable(data) {
        var reader = Windows.Storage.Streams.DataReader.fromBuffer(data);
        var printable = true;
        for (var byteIndex = 0; printable && byteIndex < data.length; ++byteIndex) {
            var c = reader.readByte();
            printable = (c >= 32 && c <= 126) || (c >= 9 && c <= 13);
        }
        return printable;
    }

    function getDataLabelString(data, scanType) {

        var result = null;

        // Only certain data types contain encoded text.
        //   To keep this simple, we'll just decode a few of them.
        if (data === null) {
            result = "NO DATA";
        }
        else {
            if (isPrintable(data)) {
                var reader = Windows.Storage.Streams.DataReader.fromBuffer(data);
                result = reader.readString(data.length);
            } else {
                result = "RAW DATA: " + getDataString(data);
            }
        }

        return result;
    };

    require("cordova/exec/proxy").add("ScannerPluginBB", module.exports);
});
