cordova.define("cordova-plugin-scannerbb.scannerbb", function (require, exports, module) {
  var scannerName = "ScannerPluginBB";
  var scannerBB = {
    enable: function (successCallback, errorCallback, profileName) {
      cordova.exec(successCallback, errorCallback, scannerName, "enable", [ profileName ]);
    },
    disable: function (successCallback, errorCallback) {
      cordova.exec(successCallback, errorCallback, scannerName, "disable", []);
    }
  }
  module.exports = scannerBB;
});
